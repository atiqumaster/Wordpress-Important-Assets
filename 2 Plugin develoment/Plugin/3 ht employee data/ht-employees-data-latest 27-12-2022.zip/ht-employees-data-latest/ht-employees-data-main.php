<?php
/**
* Plugin Name:Employees Data
* Plugin URI: http//...
* Description: This plugin is for employee data.
* Author: Sajjad Ahmad
* Author:http//...
* version: 1.0.0
* Text Domain: ht-empdata
*/
if (!defined('ABSPATH')) {
	exit();
}

class Ht_Employee_Data_Main{
	public function __construct(){
		$this->ht_employeedata_global_variables();
		register_activation_hook( __FILE__,array($this, 'custom_employee_data_form_create_table' ));
		remove_action( __FILE__,array($this, 'custom_employee_data_form_remove_table'));
		add_action( 'init', array($this,'ht_gatempdata_init'));
		add_action('admin_menu', array($this, 'registe_custom_employee_data_menu'));
		add_action( 'wp_ajax_nopriv_get_emp_data',array($this, 'get_emp_data' ));
        add_action( 'wp_ajax_get_emp_data',array($this, 'get_emp_data' ));
		
	  	
			include_once EMPD_PLUGIN_DIR . 'include/front/ht-employees-data-shortcode.php';	
	}
	
	public function custom_employee_data_form_create_table(){
		global $wpdb; 
		$charset_collate = $wpdb->get_charset_collate();
		 $db_table_name = $wpdb->prefix .'custom_employee_data';  // table name

		 //Check to see if the table exists already, if not, then create it
		 if($wpdb->get_var( "show tables like '$db_table_name'" ) != $db_table_name ) 
		 {
		       $sql = "CREATE TABLE `$db_table_name` (
		                `id` int(11) NOT NULL auto_increment,
		                `name` varchar(15) NOT NULL,
		                `email` varchar(60) NOT NULL,
		                `semester` varchar(200) NOT NULL,
		                `subject` varchar(1000) NOT NULL,
		                `description` varchar(500) NOT NULL,
		                `image` varbinary(5000) NOT NULL,
		                UNIQUE KEY id (id)
		        ) $charset_collate;";
			require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
			dbDelta( $sql );
		 }
	}
	public function custom_employee_data_form_remove_table(){
		global $wpdb;
	    $table_name = $wpdb->prefix . 'custom_employee_data';
	    $sql = "DROP TABLE IF EXISTS $table_name";
	    $wpdb->query($sql);

	}
	public function ht_employeedata_global_variables() { 
		if (!defined('EMPD_URL') ) {
            define('EMPD_URL', plugin_dir_url(__FILE__));
        }

		if (! defined('EMPD_PLUGIN_DIR') ) {
			define('EMPD_PLUGIN_DIR', plugin_dir_path(__FILE__));
		}
	}
	public function registe_custom_employee_data_menu(){
	
		add_menu_page('Employee Data', 'Employee Data', 'manage_options', 'emp-info-list', array($this,'custom_employee_data_menu_page'), 'dashicons-media-text',5);
    	add_submenu_page('emp-info-list', 'Employee Data List', 'Employee Info List', 'manage_options', 'emp-info-list', array($this,'custom_employee_data_menu_page'));
    	 add_submenu_page('emp-info-list', 'Add Employee ', 'Add Employee ', 'manage_options', 'add-emp-info',array($this,'custom_employee_data_submenu_page'));
    	add_submenu_page(null, 'Update Employee Info', 'Update Employee Info', 'manage_options', 'update-emp-info',array($this, 'update_employee_info_callback'));
    	add_submenu_page(null, 'Delete Employee Info', 'Delete Employee Info', 'manage_options', 'delete-emp-info',array($this, 'delete_employee_info_callback'));
    	
	}

	public function custom_employee_data_menu_page()
	{
	    global $wpdb;
	    $table_name = $wpdb->prefix . 'custom_employee_data';
	    $employee_info_list = $wpdb->get_results($wpdb->prepare("select * FROM $table_name", ""), ARRAY_A);
	    ?>  <h1> Employees Information </h1><?php
	    if (count($employee_info_list) > 0): ?>
	        <div style="margin-top: 40px; padding:0 10px">
	            <table border="1" cellpadding="10" width="100%">
	                <tr>
	                	<th><?php echo esc_html__('ID','ht-empdata') ?></th>
	                    <th><?php echo esc_html__('Employee Name','ht-empdata') ?></th>
	                    <th><?php echo esc_html__('Email','ht-empdata') ?></th>
	                    <th><?php echo esc_html__('Semester','ht-empdata') ?></th>
	                    <th><?php echo esc_html__('Subjects','ht-empdata') ?></th>
                        <th><?php echo esc_html__('Description','ht-empdata') ?></th>
                        <th><?php echo esc_html__('Image','ht-empdata') ?></th>
	                    <?php if (is_admin()): ?>
	                        <th>Action</th>
	                    <?php endif; ?>
	                </tr>
	                <?php 
	                foreach ($employee_info_list as $key => $employee_info): ?>
	                    <tr>
	                        <td><?php echo $employee_info['id']; ?></td>
	                        <td><?php echo $employee_info['name']; ?></td>
	                        <td><?php echo $employee_info['email']; ?></td>
	                        <td><?php echo $employee_info['semester']; ?></td>
	                        <td><?php echo $employee_info['subject']; ?></td>
	                        <td><?php echo $employee_info['description']; ?></td>
	                        <td>
	                        	<?php echo $employee_info['image'] ?>
	                        	<!-- <img src="../uploads/2022/12/" width="100px" height="100px"> -->
	                        </td>
	                        <?php if (is_admin()): ?>
                            <td>
                                <a href="admin.php?page=update-emp-info&id=<?php echo $employee_info['id']; ?>">Edit</a>
                                <a href="admin.php?page=delete-emp-info&id=<?php echo $employee_info['id']; ?>">Delete</a>
                            </td>
	                        <?php endif; ?>
	                    </tr>
	                <?php endforeach; ?>
	            </table>

	        </div>
	    <?php else:echo "<h2>Employee Record Not Found</h2>";endif;
	}
	Public function custom_employee_data_submenu_page()
	{
	    global $wpdb;
	    $table_name = $wpdb->prefix . 'custom_employee_data';
	    $msg = '';
	    $add_subjects="";
	    if (isset($_REQUEST['submit'])) {
	    	if(isset($_FILES['file'])){

		            $file_Name=$_FILES['file']['name'];
		            $file_Type= $_FILES['file']['type'];
		            $file_TmpName= $_FILES['file']['tmp_name'];
		            $file_Size=$_FILES['file']['size'];
		            $allow_FTypes = array('image/jpg','image/png','image/jpeg','image/gif');
		            
		                $upload_image_path= wp_upload_bits($file_Name, null, file_get_contents($file_TmpName));
		        }
		        foreach($_REQUEST['subject'] as $add_sub){
                  $add_subjects .= $add_sub.",";
            	}
	        $wpdb->insert("$table_name", [
	            "name" => $_REQUEST['name'],
	            'email' => $_REQUEST['email'],
	            'semester' => $_REQUEST['semester'],
	            'subject' => $add_subjects,
	            'description' => $_REQUEST['description'],
	            'image' => $file_Name
	        ]);


	        if ($wpdb->insert_id > 0) {
	            $msg = "Saved Successfully";
	        } else {
	            $msg = "Failed to save data";
	        }
	    }

	    ?>
	    <h3 style="color:green;"><?php echo $msg; ?></h3>

	    <form method="post" enctype="multipart/form-data">

	        <div class="form-group">
		  	<label for="fname" style="font-size:17px; font-weight:bold;">Name</label> <br><br>
    		<input type="text" placeholder="Name"  name="name" id="fname" style="width: 400px" required>
		  </div><br>
		  <div class="form-group">
		    <label for="exampleFormControlInput1" style="font-size:17px; font-weight:bold;">Email address</label><br><br>
		    <input type="text" name="email" class="form-control" id="email" placeholder="name@example.com" style="width: 400px" required>
		  </div><br>
		  <div class="form-group">
		    <label for="exampleFormControlSelect1" style="font-size:17px; font-weight:bold;">semester select</label><br><br>
		    <select class="form-control" id="semester" name="semester" style="width: 400px" >
		      <option value="First">First</option>
		      <option value="Second">Second</option>
		      <option value="Third">Third</option>
		      <option value="Fourth">Fourth</option>
		      <option value="Five">Five</option>
		      <option value="Six ">Six </option>
		      <option value="Seventh">Seventh</option>
		      <option value="Eight ">Eight </option>
		    </select>
		  </div><br>
		  <div class="form-group">
		    <label for="exampleFormControlSelect2" style="font-size:17px; font-weight:bold;">Subjects multiple select</label><br><br>
		    <select class="form-control" name="subject[]" style="width: 400px; hight:500px;"  id="selectoption" multiple="multiple">
				<option value="Introduction to Computing">Introduction to Computing</option>
                <option value="Calculus And Analytical Geometry">Calculus And Analytical Geometry</option>
                <option value="Introduction to Programming">Introduction to Programming</option>
                <option value="Object Oriented Programming">Object Oriented Programming</option>
                <option value="Database Management Systems">Database Management Systems</option>
                <option value="Data Communication">Data Communication</option>
                <option value="Data Structures">Data Structures</option>
                <option value="Computer Networks">Computer Networks</option>
                <option value="Information Security">Information Security</option>
                <option value="Theory of Automata">Theory of Automata</option>
                <option value="Fundamentals of Algorithms">Fundamentals of Algorithms</option>
                <option value="Operating Systems">Operating Systems</option>
			</select>
		   
		  </div><br>
		  <div class="form-group">
		    <label for="exampleFormControlTextarea1" style="font-size:17px; font-weight:bold;">Description Textarea</label><br><br>
		    <input  class="form-control" name="description" id="description" style="width: 400px; hight:1000px" rows="3" ></input>
		  </div><br>
		  <div class="form-group">
		    <label for="exampleFormControlFile1" style="font-size:17px; font-weight:bold;">Upload Image File</label><br><br>
		    <input type="file" class="form-control-file" name="file" id="image">
		  </div><br>
	            <button type="submit" name="submit" style="width: 80px; hight:80px; font-weight: bold; background-color: green;">Submit</button>
	        </p>
	    </form>
	<?php }

	public function update_employee_info_callback()
	{ ?>
	    	<h1>Edit Employee Data</h1>
	    	<?php
	    	global $wpdb;
	    $table_name = $wpdb->prefix . 'custom_employee_data';
	    $msg = '';
	    $updated_subjects="";
	    $file_Name="";
	    $id = isset($_REQUEST['id']) ? intval($_REQUEST['id']) : "";
	    if (isset($_REQUEST['update'])) {
	        if (!empty($id)) {
	        	foreach($_REQUEST['subject'] as $u_sub){
                  $updated_subjects .= $u_sub.",";
            	}
            	if(isset($_FILES['file'])){

		            $file_Name=$_FILES['file']['name'];
		            $file_Type= $_FILES['file']['type'];
		            $file_TmpName= $_FILES['file']['tmp_name'];
		            $file_Size=$_FILES['file']['size'];
		            $allow_FTypes = array('image/jpg','image/png','image/jpeg','image/gif');
		            
		                $upload_image_path= wp_upload_bits($file_Name, null, file_get_contents($file_TmpName));
		            
		      
		        }
	            $wpdb->update("$table_name", ["name" => $_REQUEST['name'], 'email' => $_REQUEST['email'], 'semester' => $_REQUEST['semester'],('subject') => $updated_subjects, 'description' => $_REQUEST['description'],'image' => $file_Name],  ["id" => $id]);
	            $msg = 'Employee Information updated';
	        }
	    }
	    $employee_info_details = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name where id = %d", $id), ARRAY_A);
	     ?>
	    <h3 style="color:green;"><?php echo $msg; ?></h3>
    <form method="post" enctype="multipart/form-data">
		  <div class="form-group">
		  	<label for="fname" style="font-size:17px; font-weight:bold;">Name</label> <br><br>
    		<input type="text" placeholder="Name"  name="name" id="fname" style="width: 400px" value="<?php echo $employee_info_details['name']; ?>" required>
		  </div><br>
		  <div class="form-group">
		    <label for="exampleFormControlInput1" style="font-size:17px; font-weight:bold;">Email address</label><br><br>
		    <input type="text" name="email" class="form-control" id="email" placeholder="name@example.com" style="width: 400px" value="<?php echo $employee_info_details['email']; ?>" required>
		  </div><br>
		  <div class="form-group">
		    <label for="exampleFormControlSelect1" style="font-size:17px; font-weight:bold;">semester select</label><br><br>
		    <select class="form-control" id="semester" name="semester" style="width: 400px" value="<?php echo $employee_info_details['semester']; ?>">
		      <option value="First">First</option>
		      <option value="Second">Second</option>
		      <option value="Third">Third</option>
		      <option value="Fourth">Fourth</option>
		      <option value="Five">Five</option>
		      <option value="Six ">Six </option>
		      <option value="Seventh">Seventh</option>
		      <option value="Eight ">Eight </option>
		    </select>
		  </div><br>
		  <div class="form-group">
		    <label for="exampleFormControlSelect2" style="font-size:17px; font-weight:bold;">Subjects multiple select</label><br><br>
		    <select class="form-control" name="subject[]" style="width: 400px; hight:500px;" value="<?php echo $updated_subjects; ?>" id="selectoption" multiple="multiple">
				<option value="Introduction to Computing">Introduction to Computing</option>
                <option value="Calculus And Analytical Geometry">Calculus And Analytical Geometry</option>
                <option value="Introduction to Programming">Introduction to Programming</option>
                <option value="Object Oriented Programming">Object Oriented Programming</option>
                <option value="Database Management Systems">Database Management Systems</option>
                <option value="Data Communication">Data Communication</option>
                <option value="Data Structures">Data Structures</option>
                <option value="Computer Networks">Computer Networks</option>
                <option value="Information Security">Information Security</option>
                <option value="Theory of Automata">Theory of Automata</option>
                <option value="Fundamentals of Algorithms">Fundamentals of Algorithms</option>
                <option value="Operating Systems">Operating Systems</option>
			</select>
		   
		  </div><br>
		  <div class="form-group">
		    <label for="exampleFormControlTextarea1" style="font-size:17px; font-weight:bold;">Description Textarea</label><br><br>
		    <input  class="form-control" name="description" id="description" style="width: 400px; hight:1000px" rows="3" value="<?php echo $employee_info_details['description']; ?>"></input>
		  </div><br>
		  <div class="form-group">
		    <label for="exampleFormControlFile1" style="font-size:17px; font-weight:bold;">Upload Image File</label><br><br>
		    <input type="file" class="form-control-file" name="file" id="image">
		  </div><br>
		 <button type="submit" name="update" style="width: 80px; hight:80px; font-weight: bold; background-color: yellow;">Update</button>
		</form>

<?php }
     
    public function delete_employee_info_callback()
    {
    	?>
    	<h1>Employee Data</h1>
    	<?php
    	global $wpdb;
   $table_name = $wpdb->prefix . 'custom_employee_data';
    $id = isset($_REQUEST['id']) ? intval($_REQUEST['id']) : "";
    if (isset($_REQUEST['delete'])) {
        if ($_REQUEST['conf'] == 'yes') {
            $row_exits = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id), ARRAY_A);
            if (count($row_exits) > 0) {
                $wpdb->delete("$table_name", array('id' => $id,));
            }
        } ?>
        <script>
            location.href = "<?php echo site_url(); ?>/wp-admin/admin.php?page=emp-info-list";
        </script>
    <?php } ?>
    <form method="post">
        <p>
            <label style="font-weight: bold;">Are you sure want delete employee infomation?</label><br>
            <input type="radio" name="conf" value="yes">Yes
            <input type="radio" name="conf" value="no" checked>No
        </p>
        <p>
            <button type="submit" name="delete" style="background-color: red; font-weight: bold;">Delete</button>
            <input type="hidden" name="id" value="<?php echo $id; ?>">
        </p>
    </form> <?php 
    }
   

	public function get_emp_data(){
		global $wpdb;
		$subject="";
		$table_name = $wpdb->prefix . 'custom_employee_data';
		$msg = '';
		$name=$_POST['name'];
		$email=$_POST['email'];
		$semester=$_POST['semester'];
		foreach($_POST['subject'] as $in_sub){
                  $subjects .= $in_sub.",";
            	}
		$description = $_POST['description'];

		if(isset($_FILES['file'])){
            $fileName=$_FILES['file']['name'];
            $fileType= $_FILES['file']['type'];
            $fileTmpName= $_FILES['file']['tmp_name'];
            $fileSize=$_FILES['file']['size'];
            $allowFTypes = array('image/jpg','image/png','image/jpeg','image/gif');
            if(in_array($fileType, $allowFTypes)){ 
                $upload_image_path= wp_upload_bits($fileName, null, file_get_contents($fileTmpName));
            }
             
        }
        echo "<pre>";
        print_r($_FILES);
        print_r($upload_image_path);
		$wpdb->query("INSERT INTO $table_name(`name`, `email`, `semester`, `subject`, `description`,`image`) VALUES ('$name','$email','$semester','$subjects','$description','$fileName')");
		if ($wpdb->insert_id > 0) {
            $msg = "Saved Successfully";
        } else {
            $msg = "Failed to save data";
        }
			wp_send_json(true);
			die();
	}

	public function ht_gatempdata_init() {
		if ( function_exists( 'load_plugin_textdomain' ) ) { 
			load_plugin_textdomain( 'ht-empdata', false, dirname( plugin_basename(__FILE__) ) . '/languages' ); 
		} 
	}

}
if (class_exists('Ht_Employee_Data_Main')){

	new Ht_Employee_Data_Main();
}




