<?php

if (!defined('ABSPATH')) {
    exit();
}
class Ht_Employee_Data_Admin {

    public function __construct() 
    {   
       
        // add_action( 'admin_init' , array($this,'add_custom_employee_infO_table')); 

    }
    public function add_custom_employee_infO_table(){
        

    }
    public function employee_info_page_clbk(){

    }

}
if (class_exists('Ht_Employee_Data_Admin')) {
    new Ht_Employee_Data_Admin();
}