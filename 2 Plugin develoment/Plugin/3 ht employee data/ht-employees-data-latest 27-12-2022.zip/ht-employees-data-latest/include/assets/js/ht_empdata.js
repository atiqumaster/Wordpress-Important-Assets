jQuery(document).ready(function($){

    var ajax_url= EMPD_handler.admin_url;
    
    jQuery('#emp_data').on('submit', function(event) {
    event.preventDefault();
    
    var name=$('#fname').val();
    var mail=$('#email').val();
    var semester =$('#semester ').val();
    var subjects = [];  
           $('input[type=checkbox]').each(function(){  
                if($(this).is(":checked")){  
                     subjects.push($(this).val());  1
                }  
           }); 
    subjects = subjects.toString();
    var description=$('#description').val();
    var image=$('#image').val();
    var form_data = new FormData(this);
    form_data.append('action', 'get_emp_data');
    if (fname == "") {
        document.getElementById('name-error').innerHTML = "*Please Enter Name"
        return false;
    }
    else if (fname.length < 3) {
        document.getElementById('name-error').innerHTML = "*Name should be minimum 3 characters"
        return false;
    }
    else{
        document.getElementById('name-error').innerHTML=""
    }
    if (mail == "") {
        document.getElementById('email-error').innerHTML = "*Please Enter Email Address"
        return false;
    }
    else if (mail.indexOf('@')<=0 ) {
        document.getElementById('email-error').innerHTML = "*Enter Valid Email Address"
        return false;
    }
    else{
        document.getElementById('email-error').innerHTML=""
    }
    if (semester == "") {
        document.getElementById('semester-error').innerHTML = "*Please Select Semester "
        return false;
    }
    else{
        document.getElementById('semester-error').innerHTML=""
    }
    if (subjects == "") {
        document.getElementById('subjects-error').innerHTML = "*Please Checked minimum 1 Subjects"
        return false;
    }
    else{
        document.getElementById('subjects-error').innerHTML=""
    }
    if (description == "") {
        document.getElementById('description-error').innerHTML = "*Please Enter Description"
        return false;
    }
    else{
        document.getElementById('description-error').innerHTML=""
    }
    if (image == "") {
        document.getElementById('image-error').innerHTML = "*Please Upload Image File"
        return false;
    }
    else{
        document.getElementById('image-error').innerHTML=""
    }
    
     $.ajax({
         url: ajax_url,
            type: 'post',
            contentType: false,
            processData: false,
            data: form_data,
        
        
         success: function (response) {
          var jsonData = JSON.parse(response);
          var res = response;
          
          if(response==true){
            alert("Form Successfuly Summited");
          }
        }

      });
 
  });

});


// var formData = new FormData(this);
// alert("Our form data is " + formData);
// console.log(formData);
//contentType: false,
//processData: false,
// cache: false,