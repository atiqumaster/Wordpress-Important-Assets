<?php


if (!defined('ABSPATH')) {
	exit();
}
class Ht_Shortcode_Form{

	public function __construct(){
		add_action('wp_enqueue_scripts', array($this, 'ht_empdata_shortcode_scripts') );
		add_shortcode( 'empdata',array( $this, 'ht_empdata_shortcode_function' ));
	}
	public function ht_empdata_shortcode_scripts() {
		wp_enqueue_script( 'jquery');
		wp_enqueue_style( 'dbs-shortcode', plugins_url('../assets/css/style.css', __FILE__) , false, '1.0.1');
		wp_enqueue_script( 'ht_empd_sd', plugins_url('../assets/js/ht_empdata.js',__FILE__),array('jquery'), '1.0.1');
		$EMPD_script_var = array(
                'admin_url' => admin_url('admin-ajax.php')
                // 'nonce' => wp_create_nonce('empdata-nonce'),
            );
            wp_localize_script( 'ht_empd_sd', 'EMPD_handler', $EMPD_script_var );
	}
	public function ht_empdata_shortcode_function(){
		?>
		<form id="emp_data" class="emp_data" method="post">
		  <div class="form-group">
		  	<label for="fname">Name:</label> 
    		<input type="text" placeholder="Name" name="name" id="fname" >
    		<span class="message" id="name-error"></span>
		  </div>
		  <div class="form-group">
		    <label for="exampleFormControlInput1">Email address</label>
		    <input type="text" name="email" class="form-control" id="email" placeholder="name@example.com">
		    <span class="message" id="email-error"></span>
		  </div>
		  <div class="form-group">
		    <label for="exampleFormControlSelect1">Semester select</label>
		    <span class="message" id="semester-error"></span>
		    <select class="form-control" id="semester" name="semester">
		      <option value="First">First</option>
		      <option value="Second">Second</option>
		      <option value="Third">Third</option>
		      <option value="Fourth">Fourth</option>
		      <option value="Five">Five</option>
		      <option value="Six ">Six </option>
		      <option value="Seventh">Seventh</option>
		      <option value="Eight ">Eight </option>
		    </select>
		  </div>
		  <div class="form-group">
		    <label for="exampleFormControlSelect2">Select multiple Subjects </label>
		    <span class="message" id="subjects-error"></span>
		    <ul multiple class="form-control multiselect" name="subjects[]" id="subjects">
		      <li><input type="checkbox" value="Introduction to Computing" name="subject[]">Introduction to Computing</li>
		      <li><input type="checkbox" value="Calculus And Analytical Geometry" name="subject[]">Calculus And Analytical Geometry</li>
		      <li><input type="checkbox" value="Introduction to Programming" name="subject[]">Introduction to Programming</li>
		      <li><input type="checkbox" value="Object Oriented Programming" name="subject[]">Object Oriented Programming</li>
		      <li><input type="checkbox" value="Database Management Systems" name="subject[]">Database Management Systems</li>
		      <li><input type="checkbox" value="Data Communication" name="subject[]">Data Communication</li>
		      <li><input type="checkbox" value="Data Structures" name="subject[]">Data Structures</li>
		      <li><input type="checkbox" value="Computer Networks" name="subject[]">Computer Networks</li>
		      <li><input type="checkbox" value="Information Security" name="subject[]">Information Security</li>
		      <li><input type="checkbox" value="Theory of Automata" name="subject[]">Theory of Automata</li>
		      <li><input type="checkbox" value="Fundamentals of Algorithms" name="subject[]">Fundamentals of Algorithms</li>
		      <li><input type="checkbox" value="Operating Systems" name="subject[]">Operating Systems</li>
		    </ul>
		  </div>
		  <div class="form-group">
		    <label for="exampleFormControlTextarea1">Description Textarea</label>
		    <textarea class="form-control" name="description" id="description" rows="3"></textarea>
		    <span class="message" id="description-error"></span>
		  </div>
		  <div class="form-group">
		    <label for="exampleFormControlFile1">Upload Image File</label>
		    <input type="file" class="form-control-file" name="file" id="image">
		     <span class="message" id="image-error"></span>
		  </div>
		  <button type="submit" class="btn btn-primary" name="submitform">Submit</button>
		</form>
<?php

		// return 'Hey, This is shortcode';

	}

	
}
if (class_exists('Ht_Shortcode_Form')){

	new Ht_Shortcode_Form();
}